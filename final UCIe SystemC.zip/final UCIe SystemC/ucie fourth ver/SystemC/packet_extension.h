#ifndef PACKET_EXTENSION_H
#define PACKET_EXTENSION_H

#include <tlm.h>
#include "packet.h"

// Extension class for UCIe memory transactions
struct PacketExtension : tlm::tlm_extension<PacketExtension> {
    Packet pkt;
    
    // UCIe layer tracking (as per paper's layered architecture)
    enum class TransactionPhase {
        PHY_LAYER,      // Physical layer - handles die-to-die interface
        ADAPTER_LAYER,  // Reliable link layer - ensures reliable transport
        PROTOCOL_LAYER, // CXL protocol mapping for memory operations
        COMPLETED
    } current_phase;
    
    // UCIe standard 256B flit tracking
    static const uint32_t STANDARD_FLIT_SIZE = 256;
    bool flit_complete;
    uint32_t flit_position;
    
    // UCIe reliability attributes (from adapter layer)
    bool crc_valid;
    uint8_t retry_count;
    static const uint8_t MAX_RETRIES = 3;
    
    // Memory transaction tracking
    uint32_t transaction_id;
    sc_time start_time;
    bool is_memory_read;    // CPU reading from memory
    bool is_memory_write;   // CPU writing to memory
    
    PacketExtension() : 
        current_phase(TransactionPhase::PHY_LAYER),
        flit_complete(false),
        flit_position(0),
        crc_valid(false),
        retry_count(0),
        transaction_id(0),
        start_time(sc_time_stamp()),
        is_memory_read(false),
        is_memory_write(false) {}
        
    PacketExtension(const Packet& p) : PacketExtension() {
        pkt = p;
        is_memory_read = (pkt.packet_type == CXL_MEM_READ);
        is_memory_write = (pkt.packet_type == CXL_MEM_WRITE);
    }

    virtual tlm::tlm_extension_base* clone() const override {
        PacketExtension* ext = new PacketExtension(pkt);
        ext->current_phase = current_phase;
        ext->flit_complete = flit_complete;
        ext->flit_position = flit_position;
        ext->crc_valid = crc_valid;
        ext->retry_count = retry_count;
        ext->transaction_id = transaction_id;
        ext->start_time = start_time;
        ext->is_memory_read = is_memory_read;
        ext->is_memory_write = is_memory_write;
        return ext;
    }

    virtual void copy_from(tlm_extension_base const &ext) override {
        const PacketExtension& other = static_cast<const PacketExtension&>(ext);
        pkt = other.pkt;
        current_phase = other.current_phase;
        flit_complete = other.flit_complete;
        flit_position = other.flit_position;
        crc_valid = other.crc_valid;
        retry_count = other.retry_count;
        transaction_id = other.transaction_id;
        start_time = other.start_time;
        is_memory_read = other.is_memory_read;
        is_memory_write = other.is_memory_write;
    }
    
    // UCIe layer progression (following paper's architecture)
    bool advance_phase() {
        switch(current_phase) {
            case TransactionPhase::PHY_LAYER:
                current_phase = TransactionPhase::ADAPTER_LAYER;
                return true;
            case TransactionPhase::ADAPTER_LAYER:
                if (!crc_valid && needs_retry()) return false;
                current_phase = TransactionPhase::PROTOCOL_LAYER;
                return true;
            case TransactionPhase::PROTOCOL_LAYER:
                if (!flit_complete) return false;
                current_phase = TransactionPhase::COMPLETED;
                return true;
            default:
                return false;
        }
    }
    
    // Layer status checks
    bool is_at_phy_layer() const { return current_phase == TransactionPhase::PHY_LAYER; }
    bool is_at_adapter_layer() const { return current_phase == TransactionPhase::ADAPTER_LAYER; }
    bool is_at_protocol_layer() const { return current_phase == TransactionPhase::PROTOCOL_LAYER; }
    bool is_completed() const { return current_phase == TransactionPhase::COMPLETED; }
    
    // Reliability methods from UCIe adapter layer
    bool needs_retry() const { return !crc_valid && retry_count < MAX_RETRIES; }
    bool can_retry() const { return retry_count < MAX_RETRIES; }
    void increment_retry() { retry_count++; }
    
    // Memory transaction methods
    sc_time get_latency() const { return sc_time_stamp() - start_time; }
    bool is_valid_memory_transaction() const { return is_memory_read || is_memory_write; }
};

#endif // PACKET_EXTENSION_H