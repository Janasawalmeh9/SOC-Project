#include "protocol.h"
#include "packet_extension.h"
#include <iostream>

void ProtocolLayer::b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay) {
    //  protocol processing delay
   std::cout << sc_time_stamp() << " [LayerName]: Accumulated delay = " << delay << std::endl;
    sc_core::sc_time protocol_delay(10, sc_core::SC_NS);
    delay += protocol_delay;
    wait(protocol_delay); 

    PacketExtension* ext = nullptr;
    trans.get_extension(ext);
    
    std::cout << sc_time_stamp() << " Protocol: Received transaction, ext: " 
              << (ext ? "valid" : "null") << "\n";
    
    if (!ext || !validate_transaction(ext)) {
        std::cout << sc_time_stamp() << " Protocol: Invalid transaction or extension\n";
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }

    // Copy extension
    PacketExtension* new_ext = new PacketExtension(*ext);
    trans.set_extension(new_ext);

    if (ext->is_memory_read) {
        process_memory_read(new_ext, delay, trans);
    } else if (ext->is_memory_write) {
        process_memory_write(new_ext, delay, trans);
    }

}

void ProtocolLayer::process_memory_read(PacketExtension* ext, sc_core::sc_time& delay, tlm::tlm_generic_payload& parent_trans)
{
    sc_time start_time = sc_time_stamp(); 

    if (!validate_transaction(ext)) {
        handle_protocol_error(ext);
        return;
    }

    std::cout << sc_time_stamp() << " Protocol: Processing read, addr: 0x" 
              << std::hex << ext->pkt.address << std::dec << ", len: " << ext->pkt.length << "\n";

    tlm::tlm_generic_payload* trans = new tlm::tlm_generic_payload;
    unsigned char* data = new unsigned char[ext->pkt.length];
    
    trans->set_command(tlm::TLM_READ_COMMAND);
    trans->set_address(ext->pkt.address);
    trans->set_data_ptr(data);
    trans->set_data_length(ext->pkt.length);
    trans->set_streaming_width(ext->pkt.length);
    trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);

    // Copy extension
    PacketExtension* new_ext = new PacketExtension(*ext);
    trans->set_extension(new_ext);

    initiator_socket->b_transport(*trans, delay);
    parent_trans.set_response_status(trans->get_response_status());

    sc_time latency = sc_time_stamp() - start_time; 

    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        if (ext->pkt.payload.size() < ext->pkt.length) {
            ext->pkt.payload.resize(ext->pkt.length);
        }
        for (uint32_t i = 0; i < ext->pkt.length; i++) {
            ext->pkt.payload[i] = data[i];
        }
        stats.reads_processed++;
        stats.total_transactions++;
        stats.total_latency += latency; 
        update_statistics(ext);
        ext->flit_complete = true;
        ext->advance_phase();
    } else {
        handle_protocol_error(ext);
    }

    delete[] data;
    delete trans;
}

void ProtocolLayer::process_memory_write(PacketExtension* ext, sc_core::sc_time& delay, tlm::tlm_generic_payload& parent_trans) {
    sc_time start_time = sc_time_stamp();

    if (!validate_transaction(ext)) {
        handle_protocol_error(ext);
        return;
    }

    std::cout << sc_time_stamp() << " Protocol: Processing write, addr: 0x" 
              << std::hex << ext->pkt.address << std::dec << ", len: " << ext->pkt.length << "\n";

    tlm::tlm_generic_payload* trans = new tlm::tlm_generic_payload;
    unsigned char* data = new unsigned char[ext->pkt.length];
    if (ext->pkt.payload.size() < ext->pkt.length) {
        std::cout << sc_time_stamp() << " Protocol: Invalid payload size\n";
        delete[] data;
        delete trans;
        return;
    }
    for (uint32_t i = 0; i < ext->pkt.length; i++) {
        data[i] = ext->pkt.payload[i].to_uint();
    }
    
    trans->set_command(tlm::TLM_WRITE_COMMAND);
    trans->set_address(ext->pkt.address);
    trans->set_data_ptr(data);
    trans->set_data_length(ext->pkt.length);
    trans->set_streaming_width(ext->pkt.length);
    trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);

    // Copy extension
    PacketExtension* new_ext = new PacketExtension(*ext);
    trans->set_extension(new_ext);

    initiator_socket->b_transport(*trans, delay);
    parent_trans.set_response_status(trans->get_response_status());

    sc_time latency = sc_time_stamp() - start_time;

    if (trans->get_response_status() == tlm::TLM_OK_RESPONSE) {
        stats.writes_processed++;
        stats.total_transactions++;
        stats.total_latency += latency;
        update_statistics(ext);
        ext->flit_complete = true;
        ext->advance_phase();
    } else {
        handle_protocol_error(ext);
    }

    delete[] data;
    delete trans;
}

void ProtocolLayer::update_statistics(const PacketExtension* ext) {
    sc_time transaction_time = sc_time_stamp() - ext->start_time;
    stats.update_latency(transaction_time);

    // Add this line to keep avg_latency up to date:
    stats.avg_latency = (stats.total_transactions > 0) ? stats.total_latency.to_double() / stats.total_transactions : 0.0;

    std::cout << sc_core::sc_time_stamp() 
              << " Protocol Layer: Transaction completed in " 
              << transaction_time << "\n"
              << "  Avg latency: " << stats.avg_latency << " s\n"
              << "  Total transactions: " << stats.total_transactions << "\n";
}

bool ProtocolLayer::validate_transaction(const PacketExtension* ext) {
    if (!config.support_256b_flit) {
        std::cout << "Error: 256B flit format not supported\n";
        return false;
    }

    if (!ext->is_memory_read && !ext->is_memory_write) {
        std::cout << "Error: Invalid memory operation\n";
        return false;
    }

    if (ext->pkt.length == 0 || ext->pkt.length > config.max_payload_size) {
        std::cout << "Error: Invalid payload length: " << ext->pkt.length << "\n";
        return false;
    }

    return true;
}

void ProtocolLayer::protocol_monitor() {
    while (true) {
        wait(clk->posedge_event());
        
        std::cout << sc_time_stamp() 
                  << " Protocol Monitor:"
                  << "\n  Reads processed: " << stats.reads_processed
                  << "\n  Writes processed: " << stats.writes_processed
                  << "\n  Flow control stalls: " << stats.flow_control_stalls
                  << "\n  Average latency: " << stats.avg_latency * 1e9 << " ns\n";
                  
        if (config.flow_control_enabled && !check_flow_control()) {
            stats.flow_control_stalls++;
        }
        
        wait(1000, SC_NS);  // Monitor every 1us
    }
}

void ProtocolLayer::handle_protocol_error(PacketExtension* ext) {
    std::cout << sc_time_stamp() 
              << " Protocol Error: Transaction failed"
              << "\n  Address: 0x" << std::hex << ext->pkt.address << std::dec
              << "\n  Operation: " << (ext->is_memory_read ? "Read" : "Write")
              << "\n  Length: " << ext->pkt.length << " bytes"
              << "\n  Current phase: " << static_cast<int>(ext->current_phase)
              << "\n  Transaction ID: " << ext->transaction_id
              << "\n  Latency: " << ext->get_latency() << "\n";
              
    stats.flow_control_stalls++;
    
    ext->current_phase = PacketExtension::TransactionPhase::PHY_LAYER;
    ext->crc_valid = false;
}
bool ProtocolLayer::check_flow_control() {
    return true;
}