#ifndef PHY_H
#define PHY_H

#include <systemc.h>
#include <tlm_utils/simple_target_socket.h>
#include <tlm_utils/simple_initiator_socket.h>
#include <vector>
#include <map>
#include <algorithm>
#include "packet.h"
#include "packet_extension.h"

SC_MODULE(PHY) {
public:
    // TLM sockets
    tlm_utils::simple_target_socket<PHY> target_socket;
    tlm_utils::simple_initiator_socket<PHY> initiator_socket;

    // Clock and control signals
    sc_in<bool> clk;
    sc_in<bool> reset;

    // Constructor
    SC_HAS_PROCESS(PHY);
    explicit PHY(sc_module_name name);

    // UCIe configuration
    struct UCIeConfig {
        enum PackageType { STANDARD, ADVANCED } package_type;
        enum DataRate { GT_4 = 4, GT_8 = 8, GT_12 = 12, GT_16 = 16, GT_24 = 24, GT_32 = 32 } data_rate;
        
        static const int STD_PACKAGE_LANES = 16;
        static const int ADV_PACKAGE_LANES_32 = 32;
        static const int ADV_PACKAGE_LANES_64 = 64;
        
        // Power targets as fixed-point values (mW)
        static constexpr int POWER_TARGET_STD_mW = 500;  // 0.5 pJ/bit
        static constexpr int POWER_TARGET_ADV_mW = 250;  // 0.25 pJ/bit
        
        // Configuration parameters
        bool automotive_features;
        int num_modules;
        int lanes_per_module;
        int total_lanes;
        int spare_lanes;
        bool lane_reversal_support;
        bool dynamic_clock_gating;
        bool scrambling_enabled;
        
        // Margin configurations
        double min_voltage_margin;
        double min_timing_margin;
        double nominal_voltage_margin;
        double nominal_timing_margin;
        int active_lanes;
        int min_lanes;
        
        UCIeConfig() :
            package_type(STANDARD),
            data_rate(GT_16),
            automotive_features(false),
            num_modules(1),
            lanes_per_module(16),
            total_lanes(16),
            spare_lanes(2),
            lane_reversal_support(true),
            dynamic_clock_gating(true),
            scrambling_enabled(true),
            min_voltage_margin(0.15),    // 15% minimum margin
            min_timing_margin(0.2),      // 20% minimum margin
            nominal_voltage_margin(0.3),  // 30% nominal margin
            nominal_timing_margin(0.35),  // 35% nominal margin
            active_lanes(16),
            min_lanes(4) {}
    } config;

    // Link states
    enum LinkState {
        RESET,
        TRAINING,
        L0_STATE,
        L1_POWER_SAVE,
        L2_POWER_SAVE,
        ERROR_RECOVERY,
        ACTIVE
    } current_state;

    // Interface methods
    void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay);

protected:
    // Package handling methods
    void handle_advanced_package_transfer(tlm::tlm_generic_payload& trans);
    void handle_standard_package_transfer(tlm::tlm_generic_payload& trans);

    // Margin and monitoring methods
    bool check_voltage_margins();  
    bool check_timing_margins();   
    double calculate_eye_margin(int lane_id);
    void handle_margin_violation(int lane_id);
    void monitor_eye_margins();
    void lane_monitoring();
    void phy_state_machine();

    // Power management methods
    void power_management();
    void enter_power_save_state(LinkState state);
    void power_down_lanes();
    void handle_forwarded_clock();

    // Runtime test methods
    void perform_runtime_test();
    void check_eye_margin_registers();
    void perform_parity_injection();
    void inject_parity_error(int lane_id);

    // Helper methods
    void parameter_exchange();
    void validate_configuration();
    void check_package_compatibility();
    void verify_lane_configuration();
    void setup_spare_lanes();
    double calculate_power_consumption();
    void perform_lane_repair();
    void width_degradation();
    bool attempt_recovery();
    
    // New helper methods
    int count_operational_lanes() const;
    bool validate_margins(int lane_id);
    void update_lane_statistics(int lane_id);

private:
    // Statistics tracking
    struct Statistics {
        uint64_t packets_processed;
        uint64_t crc_errors;
        uint64_t margin_violations;
        uint32_t lane_repairs;
        uint32_t runtime_tests_completed;
        uint64_t margin_recoveries;
        uint64_t width_degradations;
        std::vector<double> eye_margins_per_lane;
        
        Statistics() : 
            packets_processed(0),
            crc_errors(0),
            margin_violations(0),
            lane_repairs(0),
            runtime_tests_completed(0),
            margin_recoveries(0),
            width_degradations(0) {}
    } stats;

    // Lane status tracking
    struct LaneStatus {
        bool active;
        bool is_spare;
        double eye_margin;
        uint32_t error_count;
        bool operational;
        double voltage_margin;
        double timing_margin;
        sc_time last_error_time;
        
        LaneStatus() : 
            active(true),
            is_spare(false),
            eye_margin(1.0),
            error_count(0),
            operational(true),
            voltage_margin(0.3),
            timing_margin(0.35),
            last_error_time(sc_time_stamp()) {}
    };

    // Module structure
    struct UCIeModule {
        int module_id;
        bool initialized;
        std::vector<bool> data_lanes;
        sc_time last_training_time;

        UCIeModule() : 
            module_id(0), 
            initialized(false),
            last_training_time(sc_time_stamp()) {}
    };

    // Sideband interface
    struct SidebandInterface {
        std::map<std::string, int> negotiated_params;
        bool parameter_exchange_done;
        sc_time last_exchange_time;
        
        SidebandInterface() : 
            parameter_exchange_done(false),
            last_exchange_time(sc_time_stamp()) {}
    } sideband;

    // Member variables
    std::vector<UCIeModule> modules;
    std::vector<LaneStatus> lane_status;
    std::map<uint32_t, uint32_t> control_registers;
    uint32_t training_cycles;
    bool scrambling_enabled;
    bool forward_clock_gated;
    sc_time last_activity;
    sc_time last_margin_check;
    sc_time margin_check_interval;
};

#endif // PHY_H