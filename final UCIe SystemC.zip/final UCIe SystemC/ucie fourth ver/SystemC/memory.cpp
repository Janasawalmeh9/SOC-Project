#include "memory.h"
#include "packet_extension.h"
#include <iostream>
void Memory::b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay) {
    //  memory processing delay
    std::cout << sc_time_stamp() << " [Memory]: Accumulated delay = " << delay << std::endl;
    sc_core::sc_time memory_delay(20, sc_core::SC_NS);
    delay += memory_delay;
    wait(memory_delay); 

    PacketExtension* ext = nullptr;
    trans.get_extension(ext);

     std::cout << sc_time_stamp() << " Memory: Received transaction, ext: " 
              << (ext ? "valid" : "null") << "\n";
   
    if (!ext) {
        std::cout << sc_core::sc_time_stamp() << " Memory: No PacketExtension\n";
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }

    if (!validate_address(ext->pkt.address, ext->pkt.length)) {
        handle_error(ext, "Invalid memory address or length");
        trans.set_response_status(tlm::TLM_ADDRESS_ERROR_RESPONSE);
        return;
    }

    if (ext->is_memory_read) {
        handle_read_request(ext, delay);
    } else if (ext->is_memory_write) {
        handle_write_request(ext, delay);
    }

    stats.last_access_time = sc_time_stamp();
    log_access(ext, ext->is_memory_read);
    
    trans.set_response_status(tlm::TLM_OK_RESPONSE);
}
void Memory::handle_read_request(PacketExtension* ext, sc_core::sc_time& delay) {
    sc_time read_delay(config.read_latency_ns, SC_NS);
    delay += read_delay; // Accumulate delay

    size_t read_size = ext->pkt.length;
    ext->pkt.payload.resize(read_size);
    for(size_t i = 0; i < read_size; i++) {
        if(ext->pkt.address + i < memory_space.size()) {
            ext->pkt.payload[i] = memory_space[ext->pkt.address + i];
        }
    }

    // Use the accumulated delay as the latency
    stats.update_read_stats(read_size, delay);
    stats.reads_completed++;

    std::cout << sc_time_stamp() << " Memory: Read " << read_size 
              << " bytes from address 0x" << std::hex << ext->pkt.address 
              << std::dec << "\n";
}

void Memory::handle_write_request(PacketExtension* ext, sc_core::sc_time& delay) {
    sc_time write_delay(config.write_latency_ns, SC_NS);
    delay += write_delay; // Accumulate delay

    size_t write_size = ext->pkt.payload.size();

    if (ext->pkt.address + write_size > memory_space.size()) {
        std::cout << sc_time_stamp() << " Memory: Write out of bounds, addr: 0x" 
                  << std::hex << ext->pkt.address << ", size: " << std::dec << write_size << "\n";
        return;
    }

    for(size_t i = 0; i < write_size; i++) {
        memory_space[ext->pkt.address + i] = ext->pkt.payload[i].to_uint();
    }

    // Use the accumulated delay as the latency
    stats.update_write_stats(write_size, delay);
    stats.writes_completed++;

    std::cout << sc_time_stamp() << " Memory: Wrote " << write_size 
              << " bytes to address 0x" << std::hex << ext->pkt.address 
              << std::dec << "\n";
}
bool Memory::validate_address(uint64_t addr, uint32_t length) {
    if (addr >= config.size) {
        std::cout << sc_time_stamp() << " Memory: Address out of range: 0x" 
                  << std::hex << addr << std::dec << "\n";
        return false;
    }
    
    if (addr + length > config.size) {
        std::cout << sc_time_stamp() << " Memory: Address + length out of range: 0x" 
                  << std::hex << addr << ", len: " << std::dec << length << "\n";
        return false;
    }
    
    if (length > config.PAGE_SIZE && (addr % config.PAGE_SIZE != 0)) {
        std::cout << sc_time_stamp() << " Memory: Page alignment error, addr: 0x" 
                  << std::hex << addr << std::dec << ", len: " << length << "\n";
        return false;
    }
    
    return true;
}

void Memory::memory_monitor() {
    while(true) {
        wait(1000, SC_NS);
        
        std::cout << "\nMemory Statistics at " << sc_time_stamp() << ":\n"
                  << "  Reads completed: " << stats.reads_completed << "\n"
                  << "  Writes completed: " << stats.writes_completed << "\n"
                  << "  Average read latency: " << stats.avg_read_latency * 1e9 << " ns\n"
                  << "  Average write latency: " << stats.avg_write_latency * 1e9 << " ns\n"
                  << "  Total bytes read: " << stats.total_bytes_read << "\n"
                  << "  Total bytes written: " << stats.total_bytes_written << "\n\n";
    }
}

void Memory::log_access(const PacketExtension* ext, bool is_read) {
    std::cout << sc_time_stamp() 
              << " Memory Access: " << (is_read ? "Read" : "Write")
              << " at address 0x" << std::hex << ext->pkt.address
              << " length: " << std::dec << ext->pkt.length
              << " transaction ID: " << ext->transaction_id << "\n";
}

void Memory::handle_error(PacketExtension* ext, const std::string& error_msg) {
    std::cout << sc_time_stamp() << " Memory Error: " << error_msg
              << " (addr: 0x" << std::hex << ext->pkt.address 
              << ", len: " << std::dec << ext->pkt.length << ")\n";
}