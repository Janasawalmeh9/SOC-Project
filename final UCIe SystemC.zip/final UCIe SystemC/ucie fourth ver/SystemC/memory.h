#ifndef MEMORY_H
#define MEMORY_H

#include <systemc.h>
#include <tlm.h>
#include <tlm_utils/simple_target_socket.h>
#include "packet.h"
#include "packet_extension.h"
#include <vector>
#include <map>

SC_MODULE(Memory) {
    // TLM socket for receiving memory requests
    tlm_utils::simple_target_socket<Memory> socket;

    // Memory configuration
    struct MemConfig {
        uint64_t size;                    // Memory size in bytes
        uint32_t read_latency_ns;         // Read operation latency
        uint32_t write_latency_ns;        // Write operation latency
        static const uint32_t PAGE_SIZE = 4096;  // 4KB pages
        
        MemConfig() : 
            size(1024 * 1024 * 1024),     // 1GB default
            read_latency_ns(50),           // 50ns read latency
            write_latency_ns(100) {}       // 100ns write latency
    } config;

    // Memory statistics
    struct MemStats {
        uint64_t reads_completed;
        uint64_t writes_completed;
        uint64_t total_bytes_read;
        uint64_t total_bytes_written;
        double avg_read_latency;
        double avg_write_latency;
        sc_time last_access_time;
        
        MemStats() : 
            reads_completed(0),
            writes_completed(0),
            total_bytes_read(0),
            total_bytes_written(0),
            avg_read_latency(0),
            avg_write_latency(0) {}

        void update_read_stats(uint32_t bytes, sc_time latency) {
            reads_completed++;
            total_bytes_read += bytes;
            avg_read_latency = ((avg_read_latency * (reads_completed - 1)) + 
                               latency.to_seconds()) / reads_completed;
        }

        void update_write_stats(uint32_t bytes, sc_time latency) {
            writes_completed++;
            total_bytes_written += bytes;
            avg_write_latency = ((avg_write_latency * (writes_completed - 1)) + 
                                latency.to_seconds()) / writes_completed;
        }
    } stats;

    SC_CTOR(Memory) : socket("socket") {
        // Register callbacks
        socket.register_b_transport(this, &Memory::b_transport);
        
        // Initialize memory
        memory_space.resize(config.size, 0);
        
        // Register monitoring thread
        SC_THREAD(memory_monitor);
    }

    // TLM interface
    void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay);

private:
    // Memory storage
    std::vector<uint8_t> memory_space;
    
    // Memory access methods
    void handle_read_request(PacketExtension* ext, sc_core::sc_time& delay);
    void handle_write_request(PacketExtension* ext, sc_core::sc_time& delay);
    bool validate_address(uint64_t addr, uint32_t length);
    
    // Monitoring and statistics
    void memory_monitor();
    void log_access(const PacketExtension* ext, bool is_read);
    void update_statistics(const PacketExtension* ext, sc_core::sc_time latency);
    
    // Error handling
    void handle_error(PacketExtension* ext, const std::string& error_msg);
};

#endif // MEMORY_H