#include "adapter.h"
#include "packet_extension.h"
#include <iostream>
#include <random>

DieToDieAdapter::DieToDieAdapter(sc_module_name name) : 
    sc_module(name),
    target_socket("target_socket"),
    init_socket("init_socket"),
    clk("clk"),
    reset("reset"),
    state(RESET) 
{
    target_socket.register_b_transport(this, &DieToDieAdapter::b_transport);
    
    SC_THREAD(link_management);
    sensitive << clk.pos();
    
    SC_THREAD(reliability_monitor);
    sensitive << clk.pos();
    
    retry_buffer.packets.resize(config.retry_buffer_size);
}

void DieToDieAdapter::b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay) {
   
    std::cout << sc_time_stamp() << " [Adapter]: Accumulated delay = " << delay << std::endl;
    // Add adapter processing delay (e.g., 10 ns)
    sc_core::sc_time adapter_delay(10, sc_core::SC_NS);
    delay += adapter_delay;
    wait(adapter_delay); 
    

    PacketExtension* ext = nullptr;
    trans.get_extension(ext);
    
    std::cout << sc_time_stamp() << " Adapter: Received transaction, ext: " 
              << (ext ? "valid" : "null") << "\n";
    
    if (!ext || !ext->pkt.payload.size()) {
        std::cout << sc_time_stamp() << " Adapter: Invalid extension or empty payload\n";
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }
    if (trans.get_command() == tlm::TLM_WRITE_COMMAND && !trans.get_data_ptr()) {
        std::cout << sc_time_stamp() << " Adapter: Invalid data_ptr for write\n";
        trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
        return;
    }

    switch(state) {
        case ACTIVE:
            if (process_active_transaction(trans, ext, delay)) {
                ext->advance_phase();
            }
            break;
            
        case ERROR_RECOVERY:
            handle_error_recovery(trans, ext);
            break;
            
        default:
            std::cout << sc_core::sc_time_stamp() 
                      << " Adapter: Link not ready, state: " << state << "\n";
            trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
    }
}

bool DieToDieAdapter::process_active_transaction(
    tlm::tlm_generic_payload& trans, 
    PacketExtension* ext,
    sc_core::sc_time& delay) 
{
    std::cout << sc_time_stamp() << " Adapter: Processing transaction, addr: 0x" 
              << std::hex << ext->pkt.address << std::dec << ", len: " << ext->pkt.length << "\n";
    
    if (!validate_flit_format(ext->pkt)) {
        std::cout << sc_core::sc_time_stamp() 
                  << " Adapter: Invalid flit format\n";
        retry_packet(trans);
        return false;
    }

    if (config.error_detection_enabled && !check_crc(ext->pkt)) {
        stats.crc_errors++;
        std::cout << sc_time_stamp() << " Adapter: CRC error detected\n";
        retry_packet(trans);
        return false;
    }

    ext->crc_valid = true;
    process_flit(ext->pkt);
    
    PacketExtension* new_ext = new PacketExtension(*ext);
    trans.set_extension(new_ext);
    
    sc_core::sc_time layer_delay(5, sc_core::SC_NS);
    delay += layer_delay; // Accumulate delay
    init_socket->b_transport(trans, delay);
    
    if (trans.get_response_status() == tlm::TLM_OK_RESPONSE) {
        stats.packets_processed++; // Increment only on success
        return true;
    }
    return false;
}

void DieToDieAdapter::process_flit(Packet& pkt) {
    uint8_t type = pkt.packet_type.to_uint();
    
    switch(static_cast<PacketType>(type)) {
        case PROTOCOL_DATA:
            if (config.dynamic_multiplexing) {
                handle_protocol_multiplexing(pkt);
            }
            break;
            
        case RETRY_REQUEST:
            handle_retry_request(pkt);
            break;
            
        case CONTROL:
            handle_control_packet(pkt);
            break;
            
        default:
            std::cout << sc_core::sc_time_stamp() 
                      << " Adapter: Invalid packet type: " << type << "\n";
            break;
    }
    
    update_statistics(pkt, true);
}

void DieToDieAdapter::handle_retry_request(const Packet& pkt) {
    stats.retries++;
    Packet retry_pkt;
    if (retry_buffer.pop(retry_pkt)) {
        process_flit(retry_pkt);
        stats.successful_retries++;
        std::cout << sc_time_stamp() << " Adapter: Successful retry\n";
    }
}

void DieToDieAdapter::handle_protocol_multiplexing(const Packet& pkt) {
    uint8_t protocol_id = pkt.payload[0].to_uint();
    std::cout << sc_core::sc_time_stamp() 
              << " Adapter: Multiplexing protocol ID: " << (int)protocol_id << "\n";
}

void DieToDieAdapter::handle_control_packet(const Packet& pkt) {
    switch(pkt.payload[0].to_uint()) {
        case 0x01:
            state = TRAINING;
            break;
        case 0x02:
            handle_power_state_change(pkt);
            break;
        case 0x03:
            update_configuration(pkt);
            break;
    }
}

void DieToDieAdapter::link_management() {
    while (true) {
        wait(clk.posedge_event());
        wait(1, SC_NS);
        
        switch (state) {
            case RESET:
                if (!reset.read()) {
                    state = INIT;
                    std::cout << sc_core::sc_time_stamp() 
                             << " Adapter: Exiting reset\n";
                }
                break;
                
            case INIT:
                state = PARAMETER_EXCHANGE;
                break;
                
            case PARAMETER_EXCHANGE:
                handle_parameter_exchange();
                state = LINK_UP;
                break;
                
            case LINK_UP:
                state = ACTIVE;
                std::cout << sc_core::sc_time_stamp() 
                         << " Adapter: Link active\n";
                break;
                
            case ERROR_RECOVERY:
                if (attempt_recovery()) {
                    state = ACTIVE;
                }
                break;
        }
    }
}

void DieToDieAdapter::reliability_monitor() {
    while (true) {
        wait(1000, SC_NS);
        
        stats.update_ber();
        if (stats.bit_error_rate > 1e-15) {
            enter_error_recovery();
        }
        
        check_retry_buffer_status();
    }
}

bool DieToDieAdapter::check_crc(const Packet& pkt) {
    uint16_t computed_crc = 0xFFFF;
    
    computed_crc = update_crc16(computed_crc, pkt.packet_type.to_uint());
    for (int i = 0; i < 8; i++) {
        computed_crc = update_crc16(computed_crc, (pkt.address >> (i * 8)) & 0xFF);
    }
    for (int i = 0; i < 4; i++) {
        computed_crc = update_crc16(computed_crc, (pkt.length >> (i * 8)) & 0xFF);
    }
    
    for (auto byte : pkt.payload) {
        computed_crc = update_crc16(computed_crc, byte.to_uint());
    }
    
    return computed_crc == pkt.crc; 
}

uint16_t DieToDieAdapter::update_crc16(uint16_t crc, uint8_t data) {
    crc ^= data << 8;
    for (int i = 0; i < 8; i++) {
        crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
    }
    return crc;
}

void DieToDieAdapter::check_retry_buffer_status() {
    size_t buffer_usage = (retry_buffer.tail - retry_buffer.head + retry_buffer.packets.size()) 
                         % retry_buffer.packets.size();
    
    if (buffer_usage > (config.retry_buffer_size * 0.9)) {
        std::cout << sc_core::sc_time_stamp() 
                  << " Adapter: Warning - Retry buffer near full: " 
                  << buffer_usage << "/" << config.retry_buffer_size << "\n";
    }
}

void DieToDieAdapter::update_statistics(const Packet& pkt, bool crc_valid) {
    if (!crc_valid) {
        stats.crc_errors++;
    }
    stats.update_ber();
}

void DieToDieAdapter::handle_error_recovery(tlm::tlm_generic_payload& trans, PacketExtension* ext) {
    trans.set_response_status(tlm::TLM_GENERIC_ERROR_RESPONSE);
    std::cout << sc_core::sc_time_stamp() 
              << " Adapter: Error recovery in progress\n";
}

bool DieToDieAdapter::attempt_recovery() {
    static int recovery_attempts = 0;
    recovery_attempts++;
    
    if (recovery_attempts > 3) {
        recovery_attempts = 0;
        return false;
    }
    
    wait(100, SC_NS);
    return true;
}

void DieToDieAdapter::handle_power_state_change(const Packet& pkt) {
    std::cout << sc_core::sc_time_stamp() 
              << " Adapter: Processing power state change request\n";
}

void DieToDieAdapter::update_configuration(const Packet& pkt) {
    std::cout << sc_core::sc_time_stamp() 
              << " Adapter: Updating configuration parameters\n";
}

bool DieToDieAdapter::validate_flit_format(const Packet& pkt) {
    if (pkt.length > PacketExtension::STANDARD_FLIT_SIZE) {
        std::cout << sc_time_stamp() 
                  << " Adapter: Invalid flit size: " << pkt.length << "\n";
        return false;
    }
    
    uint8_t type = pkt.packet_type.to_uint();
    if (type > static_cast<uint8_t>(PacketType::MAX_TYPE)) {
        std::cout << sc_time_stamp() 
                  << " Adapter: Invalid packet type: " << type << "\n";
        return false;
    }
    
    return true;
}

void DieToDieAdapter::retry_packet(const tlm::tlm_generic_payload& trans) {
    PacketExtension* ext = nullptr;
    trans.get_extension(ext);
    
    if (ext && ext->can_retry()) {
        stats.retries++;
        retry_buffer.push(ext->pkt);
        ext->increment_retry();
        std::cout << sc_time_stamp() 
                  << " Adapter: Queuing packet for retry\n";
    } else {
        enter_error_recovery();
    }
}

void DieToDieAdapter::enter_error_recovery() {
    state = ERROR_RECOVERY;
    std::cout << sc_time_stamp() 
              << " Adapter: Entering error recovery state\n";
              
    retry_buffer.clear();
}

void DieToDieAdapter::handle_parameter_exchange() {
    std::cout << sc_time_stamp() 
              << " Adapter: Performing parameter exchange\n";
              
    config.flit_size = PacketExtension::STANDARD_FLIT_SIZE;
    config.error_detection_enabled = true;
    config.replay_mechanism_enabled = true;
    
    if (config.flit_size != PacketExtension::STANDARD_FLIT_SIZE) {
        SC_REPORT_FATAL("Adapter", "Invalid flit size configuration");
    }
    
    if (config.retry_buffer_size == 0) {
        SC_REPORT_FATAL("Adapter", "Invalid retry buffer size");
    }
}