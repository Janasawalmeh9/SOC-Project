

#ifndef ADAPTER_H
#define ADAPTER_H

#include <systemc.h>
#include <tlm_utils/simple_target_socket.h>
#include <tlm_utils/simple_initiator_socket.h>
#include <vector>
#include <map>
#include "packet.h"
#include "packet_extension.h"

// UCIe Adapter Layer Module
SC_MODULE(DieToDieAdapter) {
public:
    // Packet types for UCIe communication
    enum PacketType {
        PROTOCOL_DATA = 0,
        RETRY_REQUEST = 1,
        CONTROL = 2,
        MAX_TYPE = 3
    };

    // TLM sockets for die-to-die interface
    tlm_utils::simple_target_socket<DieToDieAdapter> target_socket;
    tlm_utils::simple_initiator_socket<DieToDieAdapter> init_socket;
    
    // Clock and control signals
    sc_in<bool> clk;
    sc_in<bool> reset;

    // UCIe adapter configuration
    struct AdapterConfig {
        static const uint16_t CRC_WIDTH = 16;    // UCIe specified 16-bit CRC
        static const uint8_t MAX_RETRIES = 3;    // Maximum retry attempts
        bool replay_mechanism_enabled;
        bool dynamic_multiplexing;               // Support for protocol multiplexing
        bool error_detection_enabled;            // Enable CRC checking
        uint32_t retry_buffer_size;             // Size of replay buffer
        uint32_t flit_size;                     // Standard UCIe flit size
        
        AdapterConfig() :
            replay_mechanism_enabled(true),
            dynamic_multiplexing(false),
            error_detection_enabled(true),
            retry_buffer_size(1024),
            flit_size(64) {}
    } config;

    // Adapter states as per UCIe spec
    enum LinkState { 
        RESET,
        INIT,
        TRAINING,
        PARAMETER_EXCHANGE,
        LINK_UP,
        ACTIVE,
        ERROR_RECOVERY
    } state;

    // Constructor
    SC_CTOR(DieToDieAdapter);

    // TLM interface methods
    void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& delay);
    bool process_active_transaction(tlm::tlm_generic_payload& trans, 
                                  PacketExtension* ext,
                                  sc_core::sc_time& delay);
    void handle_error_recovery(tlm::tlm_generic_payload& trans, PacketExtension* ext);

    // Public getter methods for statistics
    uint64_t get_packets_processed() const { return stats.packets_processed; }
    uint64_t get_crc_errors() const { return stats.crc_errors; }
    uint64_t get_retries() const { return stats.retries; }
    uint64_t get_successful_retries() const { return stats.successful_retries; }
    double get_bit_error_rate() const { return stats.bit_error_rate; }
    LinkState get_current_state() const { return state; }
    bool is_link_active() const { return state == ACTIVE; }

protected:
    // Transaction processing methods
    void process_flit(Packet& pkt);
    bool validate_flit_format(const Packet& pkt);
    void handle_protocol_multiplexing(const Packet& pkt);
    void handle_retry_request(const Packet& pkt);
    void handle_control_packet(const Packet& pkt);
    void handle_power_state_change(const Packet& pkt);
    void update_configuration(const Packet& pkt);
    void retry_packet(const tlm::tlm_generic_payload& trans);
    
    // CRC and reliability methods
    bool check_crc(const Packet& pkt);
    void generate_crc(Packet& pkt);
    uint16_t update_crc16(uint16_t crc, uint8_t data);

private:
    // Reliability tracking
    struct ReliabilityStats {
        uint64_t packets_processed;
        uint64_t crc_errors;
        uint64_t retries;
        uint64_t successful_retries;
        double bit_error_rate;
        std::vector<uint64_t> retry_history;
        
        ReliabilityStats() :
            packets_processed(0),
            crc_errors(0),
            retries(0),
            successful_retries(0),
            bit_error_rate(0.0) {
            retry_history.reserve(1000);
        }
        
        void update_ber() {
            if (packets_processed > 0) {
                bit_error_rate = static_cast<double>(crc_errors) / packets_processed;
            }
        }
    } stats;

    // Retry buffer for replay mechanism
    struct RetryBuffer {
        std::vector<Packet> packets;
        size_t head;
        size_t tail;
        
        RetryBuffer() : head(0), tail(0) {
            packets.resize(1024);
        }
        
        void push(const Packet& pkt) {
            packets[tail] = pkt;
            tail = (tail + 1) % packets.size();
        }
        
        bool pop(Packet& pkt) {
            if (head == tail) return false;
            pkt = packets[head];
            head = (head + 1) % packets.size();
            return true;
        }
        
        void clear() {
            head = tail = 0;
        }
    } retry_buffer;

    // Link management methods
    void link_management();
    void reliability_monitor();
    void handle_parameter_exchange();
    bool is_valid_state_transition(LinkState current, LinkState next) const;
    
    // Error handling methods
    void handle_crc_error(const Packet& pkt);
    void enter_error_recovery();
    bool attempt_recovery();
    void update_statistics(const Packet& pkt, bool crc_valid);

    // Runtime monitoring
    void monitor_link_quality();
    void check_retry_buffer_status();
    void update_error_counters(const Packet& pkt);
};

#endif